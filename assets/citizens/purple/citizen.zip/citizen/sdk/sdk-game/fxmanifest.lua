fx_version 'cerulean'

games { 'gta5' }

client_scripts {
	'sdk-client.js'
}

server_scripts {
	'sdk-server.js'
}
