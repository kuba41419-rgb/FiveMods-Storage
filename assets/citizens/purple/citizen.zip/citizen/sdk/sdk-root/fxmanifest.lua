fx_version 'bodacious'

client_script {
	'shell/index.js'
}
